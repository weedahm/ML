# ML
Machine Learning

필요한 라이브러리
numpy
scipy
matplotlib
scikit-learn
tensorflow
django
djangorestframework
