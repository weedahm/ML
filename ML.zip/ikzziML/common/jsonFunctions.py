import os
import json
import numpy as np

script_path = os.path.dirname(os.path.abspath(__file__))

DISEASE_ML_INPUT_MAP_PATH = script_path + '/table/diseaseMLInput_map.json'

def readJsonFile(file_path):
    with open(file_path, encoding='utf-8') as data_file:
        json_data = json.load(data_file)
    return json_data

def castToMLData(bodychart_data, num_features):
    with open(DISEASE_ML_INPUT_MAP_PATH, encoding='utf-8') as data_file:
        val_dic = json.load(data_file)

    data = np.zeros((1, num_features))

    ######## bodychart(json -> ML input Form)
    for i in val_dic.values():
        if bodychart_data[i[1]][i[2]] and type(bodychart_data[i[1]][i[2]]) == bool:
            data[0][i[0]] = 6
        elif not bodychart_data[i[1]][i[2]]: # or (bodychart_data[i[1]][i[2]] == ""):
            data[0][i[0]] = 0
        else:
            data[0][i[0]] = bodychart_data[i[1]][i[2]]

    return data
