import os
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from .common import csv2data
from .common import calcFunctions

script_path = os.path.dirname(os.path.abspath(__file__))

OUTPUT_PATH = 'output/inference_output.csv'
MODEL_PATH = script_path + '/model/patients_2layerNN_two/2layerNN.ckpt'

def inferenceNet(testX, size):
    input_size = size[0]
    hidden_size = 256
    hidden_size2 = 256
    output_size = size[1]
    
    ######### Network Model
    X = tf.placeholder(tf.float32, [None, input_size])

    W1 = tf.Variable(tf.random_normal([input_size, hidden_size], stddev=0.01))
    b1 = tf.Variable(tf.zeros([hidden_size]))
    L1 = tf.nn.relu(tf.layers.batch_normalization(tf.matmul(X, W1) + b1))

    W2 = tf.Variable(tf.random_normal([hidden_size, hidden_size2], stddev=0.01))
    b2 = tf.Variable(tf.zeros([hidden_size2]))
    L2 = tf.nn.relu(tf.layers.batch_normalization(tf.matmul(L1, W2) + b2))

    W3 = tf.Variable(tf.random_normal([hidden_size2, hidden_size2], stddev=0.01))
    b3 = tf.Variable(tf.zeros([hidden_size2]))
    L3 = tf.nn.relu(tf.layers.batch_normalization(tf.matmul(L2, W3) + b3))

    W4 = tf.Variable(tf.random_normal([hidden_size2, hidden_size2], stddev=0.01))
    b4 = tf.Variable(tf.zeros([hidden_size2]))
    L4 = tf.nn.relu(tf.layers.batch_normalization(tf.matmul(L3, W4) + b4))

    W5 = tf.Variable(tf.random_normal([hidden_size2, output_size], stddev=0.01))
    b5 = tf.Variable(tf.zeros([output_size]))

    model = tf.matmul(L4, W5) + b5

    ######### Inference
    sess = tf.Session()
    saver = tf.train.Saver()
    saver.restore(sess, MODEL_PATH)

    tf.reset_default_graph()

    predict_model = sess.run(model, feed_dict={X: testX})
    predict_model = predict_model.round(1)

    sess.close()

    ######### Writing
    import os
    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    csv2data.set_data(OUTPUT_PATH, predict_model)

    predict_model[predict_model < 0] = 0
    predict_data = (predict_model * 2).round() / 2

    return predict_data
