import os
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from .common import csv2data

script_path = os.path.dirname(os.path.abspath(__file__))

OUTPUT_PATH = 'output/inference_output_set.csv'
MODEL_PATH = script_path + '/model/patients_2layerNN_set/2layerNN.ckpt'

def inferenceNet(testX, size):
    input_size = size[0]
    hidden_size = int(input_size / 2)
    output_size = size[1] 

    ######### Network Model
    X = tf.placeholder(tf.float32, [None, input_size])

    W1 = tf.Variable(tf.random_normal([input_size, hidden_size], stddev=0.01))
    b1 = tf.Variable(tf.random_normal([hidden_size], stddev=0.1))
    L1 = tf.nn.relu(tf.layers.batch_normalization(tf.matmul(X, W1) + b1))
    
    W2 = tf.Variable(tf.random_normal([hidden_size, output_size], stddev=0.01))
    b2 = tf.Variable(tf.random_normal([output_size], stddev=0.1))
    model = tf.matmul(L1, W2) + b2
    softmax_model = tf.nn.softmax(model)

    ######### Inference
    sess = tf.Session()
    saver = tf.train.Saver()
    saver.restore(sess, MODEL_PATH)

    tf.reset_default_graph()

    predict_model = sess.run(softmax_model, feed_dict={X: testX})
    predict_model = predict_model.round(2)

    sess.close()

    ######### Writing
    import os
    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    csv2data.set_data(OUTPUT_PATH, predict_model)

    predict_data_set = np.argmax(predict_model[0]) + 1
    
    return predict_data_set
